<?php

namespace App\Status;

class OrderStatus
{
    const WAITING = 0;
    const New = 1;
    const Preparing = 2;
    const Ready = 3;
}
