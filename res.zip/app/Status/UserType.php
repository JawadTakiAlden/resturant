<?php

namespace App\Status;

class UserType
{
    const WAITER = 1;
    const KITCHEN = 2;
    const CASHER = 3;
    const ADMIN = 4;
}
